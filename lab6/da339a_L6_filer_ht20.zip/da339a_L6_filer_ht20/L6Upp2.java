public class L6Upp2{
  public static void main(String[] args) {
   int min = 10;
   int max = 25;
   int increase = 3;
      for(int i = min ; i <= max; i += increase ) {
          System.out.print( i + " " );
      }
      System.out.println();

      // skriv en while-loop som gör samma sak som for-loopen här

      // skriv en do-while-loop som gör samma sak som for-loopen här

  }
}

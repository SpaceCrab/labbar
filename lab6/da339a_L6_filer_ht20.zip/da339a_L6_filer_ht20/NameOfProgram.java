import java.util.Scanner;

/*Ändra NameOfprogram nedan till vad du lämåligtvis kallar det här
  programmet och se till att filen har samma namn enligt formen
  NameOfProgram.java
*/
public class NameOfProgram{
  public static void main(String[] args) {
   //här skriver du koden för ditt program
  }
}
